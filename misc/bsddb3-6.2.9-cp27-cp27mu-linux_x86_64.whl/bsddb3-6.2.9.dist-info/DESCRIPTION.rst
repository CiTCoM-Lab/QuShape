This module provides a nearly complete wrapping of the Oracle/Sleepycat C API
for the Database Environment, Database, Cursor, Log Cursor, Sequence and
Transaction objects, and each of these is exposed as a Python type in the
bsddb3.db module. The database objects can use various access methods: btree,
hash, recno, and queue.  Complete support of Berkeley DB distributed
transactions. Complete support for Berkeley DB Replication Manager. Complete
support for Berkeley DB Base Replication. Support for RPC.

Please see the documents in the docs directory of the source distribution or at
the website for more details on the types and methods provided. The goal is to
mirror most of the real Berkeley DB API so fall back to the Oracle Berkeley DB
documentation as appropriate.

If you need to support ancient versions of Python and/or Berkeley DB , you can
use old releases of this bindings.


`Homepage <https://www.jcea.es/programacion/
pybsddb.htm>`__ --
`Releases (changelog) <https://www.jcea.es/programacion/
pybsddb.htm#Releases>`__ --
`Documentation <https://www.jcea.es/programacion/
pybsddb_doc/>`__ --
`Mailing List <https://mailman.jcea.es/listinfo/pybsddb>`__ --
`Donation <https://www.jcea.es/programacion/pybsddb_doc/donate.html>`__

.. warning::

   This library is deprecated. If you are running Python 3 >= 3.6, please
   upgrade to `berkeleydb <https://pypi.org/project/berkeleydb/>`_ library.
   Check `details <https://www.jcea.es/programacion/pybsddb.htm>`__.

   Take note that upgrading to `berkeleydb`_ is easy but not transparent.
   Notably, keys and values are **bytes** in `berkeleydb`_ lib, while in
   'bsddb3' they are **strings**. You would only need to change your code to
   add or remove type encoding/decoding, depending of how you use the library.
   The process should be simple, nevertheless.


